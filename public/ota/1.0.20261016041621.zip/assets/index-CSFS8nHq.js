const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Bc-u9r23.js","./index-Ckr1EkHr.js","./index-DWwg-IVs.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-Ckr1EkHr.js";const o=r("App",{web:()=>p(()=>import("./web-Bc-u9r23.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
