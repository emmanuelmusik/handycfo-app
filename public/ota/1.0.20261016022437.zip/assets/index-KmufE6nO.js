const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C1ztwhuR.js","./index-CMuvoEM7.js","./index-DWwg-IVs.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-CMuvoEM7.js";const o=r("App",{web:()=>p(()=>import("./web-C1ztwhuR.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
