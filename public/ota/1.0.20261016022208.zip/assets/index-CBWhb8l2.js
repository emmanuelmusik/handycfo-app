const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DUroNJ3a.js","./index-DN4BWzod.js","./index-CWDlhlCr.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-DN4BWzod.js";const o=r("App",{web:()=>p(()=>import("./web-DUroNJ3a.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
