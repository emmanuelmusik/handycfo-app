const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-OOw8gLan.js","./index-DN4BWzod.js","./index-CWDlhlCr.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-DN4BWzod.js";const _=e("Browser",{web:()=>o(()=>import("./web-OOw8gLan.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(r=>new r.BrowserWeb)});export{_ as Browser};
