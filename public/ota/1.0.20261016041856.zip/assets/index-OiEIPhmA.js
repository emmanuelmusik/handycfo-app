const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DsZTccUC.js","./index-DBL3Jw1i.js","./index-DWwg-IVs.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-DBL3Jw1i.js";const o=r("App",{web:()=>p(()=>import("./web-DsZTccUC.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
