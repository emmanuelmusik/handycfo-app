const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Dgz09hIo.js","./index-DBL3Jw1i.js","./index-DWwg-IVs.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-DBL3Jw1i.js";const _=e("Browser",{web:()=>o(()=>import("./web-Dgz09hIo.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(r=>new r.BrowserWeb)});export{_ as Browser};
