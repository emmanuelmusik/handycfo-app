const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BavfYtVq.js","./index-_9cxOmT4.js","./index-DWwg-IVs.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-_9cxOmT4.js";const _=e("Browser",{web:()=>o(()=>import("./web-BavfYtVq.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(r=>new r.BrowserWeb)});export{_ as Browser};
