const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-kv27ihUN.js","./index-BPhNDGD8.js","./index-B5okcqbY.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-BPhNDGD8.js";const o=r("App",{web:()=>p(()=>import("./web-kv27ihUN.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
