const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-COxHJQY_.js","./index-B0IJQA6p.js","./index-B5okcqbY.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-B0IJQA6p.js";const _=e("Browser",{web:()=>o(()=>import("./web-COxHJQY_.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(r=>new r.BrowserWeb)});export{_ as Browser};
