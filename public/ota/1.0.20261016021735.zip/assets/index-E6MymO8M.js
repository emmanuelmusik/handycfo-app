const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C_WWmQIR.js","./index-DsC0vJw2.js","./index-CWDlhlCr.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-DsC0vJw2.js";const _=e("Browser",{web:()=>o(()=>import("./web-C_WWmQIR.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(r=>new r.BrowserWeb)});export{_ as Browser};
